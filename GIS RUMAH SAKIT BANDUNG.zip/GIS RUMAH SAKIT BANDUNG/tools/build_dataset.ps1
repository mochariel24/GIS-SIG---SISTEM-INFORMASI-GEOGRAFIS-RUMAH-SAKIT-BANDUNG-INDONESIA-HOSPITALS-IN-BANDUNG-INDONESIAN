$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$DataDir = Join-Path $Root 'data'
$Compiled = Get-Date -Format 'yyyy-MM-dd'

# Snapshot names follow Profil Kesehatan Kota Bandung 2025. Coordinates use
# active Kemenkes SIRS entries. Humana Prima's SIRS point is misplaced outside
# Bandung, so its point is corrected from the OSM Photon result for its official address.
$Rows = @'
id|sirsCode|name|category|type|class|lat|lng|address|coordinateSource
1|3204041|RS Umum Kebonjati|Umum|Rumah Sakit Umum|C|-6.916178345764795|107.59631963503716|Jl. Kebonjati No. 152|Kementerian Kesehatan RI - SIRS Online
2|3204123|RS Umum Humana Prima|Umum|Rumah Sakit Umum|C|-6.9408796|107.6642366|Jl. Rancabolang No. 21, Manjahlega, Rancasari|OpenStreetMap Photon - koreksi koordinat SIRS
3|3204124|RS Gigi dan Mulut Maranatha|Khusus|Khusus - Gigi dan Mulut|B|-6.886791302884248|107.58097397790982|Jl. Surya Sumantri No. 65|Kementerian Kesehatan RI - SIRS Online
4|3204129|RS Ibu dan Anak Grha Bunda|Khusus|Khusus - Ibu dan Anak|C|-6.913225622150814|107.64548511568354|Jl. Terusan Jakarta No. 15-17|Kementerian Kesehatan RI - SIRS Online
5|3204130|RS Mata Bandung Eye Center|Khusus|Khusus - Mata|C|-6.937707|107.6238201|Jl. Buah Batu No. 147|Kementerian Kesehatan RI - SIRS Online
6|3204137|RS Kartini|Umum|Rumah Sakit Umum|D|-6.897209999999976|107.63471|Jl. Pahlawan No. 48|Kementerian Kesehatan RI - SIRS Online
7|3273015|RS Umum Pusat Dr. Hasan Sadikin|Umum|Rumah Sakit Umum|A|-6.899590150319322|107.59832449611028|Jalan Pasteur No. 38|Kementerian Kesehatan RI - SIRS Online
8|3273026|RSU Bhayangkara Tk. II Sartika Asih|Umum|Rumah Sakit Umum|B|-6.956525642951864|107.61258122261502|Jalan Moch Toha No. 369|Kementerian Kesehatan RI - SIRS Online
9|3273030|RSAU dr. M. Salamun|Umum|Rumah Sakit Umum|B|-6.864352287307631|107.60505591192549|Jl. Ciumbuleuit No. 203|Kementerian Kesehatan RI - SIRS Online
10|3273052|RS Umum Immanuel Bandung|Umum|Rumah Sakit Umum|B|-6.935996215962966|107.596519666696|Jl. Kopo 161|Kementerian Kesehatan RI - SIRS Online
11|3273063|RS Umum Santo Yusup|Umum|Rumah Sakit Umum|C|-6.906669690970809|107.64288425445558|Jl. Cikutra No. 7|Kementerian Kesehatan RI - SIRS Online
12|3273074|RS Umum Santo Borromeus|Umum|Rumah Sakit Umum|B|-6.894020240862513|107.61323969778468|Jl. Ir. H. Juanda No. 100|Kementerian Kesehatan RI - SIRS Online
13|3273085|RS Umum Advent Bandung|Umum|Rumah Sakit Umum|B|-6.891986596870226|107.60327570608217|Jalan Cihampelas 161|Kementerian Kesehatan RI - SIRS Online
14|3273096|RS Umum Pindad|Umum|Rumah Sakit Umum|C|-6.93983|107.646282|Jl. Jend. Gatot Subroto No. 517|Kementerian Kesehatan RI - SIRS Online
15|3273106|RS Umum Muhammadiyah|Umum|Rumah Sakit Umum|C|-6.933487|107.62324|Jl. K.H. Ahmad Dahlan No. 53|Kementerian Kesehatan RI - SIRS Online
16|3273110|RS Umum Bungsu|Umum|Rumah Sakit Umum|D|-6.918543934193353|107.61335136938101|Jalan Veteran No. 6|Kementerian Kesehatan RI - SIRS Online
17|3273121|RS Primaya Rajawali|Umum|Rumah Sakit Umum|C|-6.9123442411585065|107.57341825067091|Jl. Rajawali Barat No. 38|Kementerian Kesehatan RI - SIRS Online
18|3273145|RS Umum Hermina Arcamanik|Umum|Rumah Sakit Umum|C|-6.904872904211322|107.66676505499032|Jl. A. H. Nasution No. 50|Kementerian Kesehatan RI - SIRS Online
19|3273165|RS Ibu dan Anak Limijati|Khusus|Khusus - Ibu dan Anak|B|-6.906056863699375|107.61361355837926|Jl. LLRE Martadinata No. 39|Kementerian Kesehatan RI - SIRS Online
20|3273176|RS Umum Tk. IV 03.07.03 Sariningsih|Umum|Rumah Sakit Umum|D|-6.906935057079031|107.6111474707127|Jl. LL. R.E. Martadinata No. 09|Kementerian Kesehatan RI - SIRS Online
21|3273191|RS Khusus Mata Cicendo|Khusus|Khusus - Mata|A|-6.910130232774372|107.60440411838529|Jalan Cicendo No. 4|Kementerian Kesehatan RI - SIRS Online
22|3273201|RS Paru Dr. H. A. Rotinsulu|Khusus|Khusus - Paru|A|-6.8775|107.6065|Jl. Bukit Jarian No. 40|Kementerian Kesehatan RI - SIRS Online
23|3273260|RS Umum Daerah Bandung Kiwari|Umum|Rumah Sakit Umum|B|-6.94239|107.59138|Jl. K.H. Wahid Hasyim No. 311|Kementerian Kesehatan RI - SIRS Online
24|3273405|RS Umum Daerah Kota Bandung|Umum|Rumah Sakit Umum|B|-6.9158488|107.6990345|Jalan Rumah Sakit No. 22|Kementerian Kesehatan RI - SIRS Online
25|3273420|RS Umum Al-Islam Bandung|Umum|Rumah Sakit Umum|B|-6.939509|107.668767|Jalan Soekarno Hatta No. 644|Kementerian Kesehatan RI - SIRS Online
26|3273431|RS Khusus Bedah Halmahera Siaga|Khusus|Khusus - Bedah|C|-6.906596229422802|107.61565859755326|Jl. LLRE Martadinata No. 28|Kementerian Kesehatan RI - SIRS Online
27|3273453|RS Khusus Ginjal Ny. R. A. Habibie|Khusus|Khusus - Ginjal|C|-6.885356599014498|107.62033760589549|Jl. Tubagus Ismail No. 46|Kementerian Kesehatan RI - SIRS Online
28|3273464|RS Khusus Gigi dan Mulut UNPAD|Khusus|Khusus - Gigi dan Mulut|A|-6.890442442680627|107.61916005438385|Jl. Sekeloa Selatan I|Kementerian Kesehatan RI - SIRS Online
29|3273486|RS Umum Santosa Hospital Bandung Central|Umum|Rumah Sakit Umum|A|-6.91533|107.60055|Jl. Kebon Jati No. 38|Kementerian Kesehatan RI - SIRS Online
30|3273528|RS Ibu dan Anak Melinda|Khusus|Khusus - Ibu dan Anak|C|-6.9088612|107.6060071|Jl. Pajajaran No. 46|Kementerian Kesehatan RI - SIRS Online
31|3273539|RS Umum Hermina Pasteur|Umum|Rumah Sakit Umum|B|-6.895872|107.588835|Jl. Dr. Djunjunan No. 107|Kementerian Kesehatan RI - SIRS Online
32|3273540|RS Khusus Gigi dan Mulut Kota Bandung|Khusus|Khusus - Gigi dan Mulut|B|-6.9061491355217015|107.61413606222186|Jl. LLRE Martadinata No. 45|Kementerian Kesehatan RI - SIRS Online
33|3273541|RS Ibu dan Anak Harapan Bunda Bandung|Khusus|Khusus - Ibu dan Anak|C|-6.9560399326118025|107.66195507126811|Pluto Raya Blok C, Margahayu Raya|Kementerian Kesehatan RI - SIRS Online
34|3273542|RS Umum Santosa Hospital Bandung Kopo|Umum|Rumah Sakit Umum|A|-6.952783586779315|107.58656503818027|Jl. K.H. Wahid Hasyim No. 461-463|Kementerian Kesehatan RI - SIRS Online
35|3273543|RS Umum Melinda 2|Umum|Rumah Sakit Umum|C|-6.906259267626762|107.59836586458741|Jl. Dr. Cipto No. 1|Kementerian Kesehatan RI - SIRS Online
36|3273546|RS Ibu dan Anak Al-Islam|Khusus|Khusus - Ibu dan Anak|C|-6.909199739488725|107.63894201384973|Jl. Awibitung No. 29-31|Kementerian Kesehatan RI - SIRS Online
37|3273547|RS Edelweiss|Umum|Rumah Sakit Umum|C|-6.94375502512403|107.64967833334134|Jl. Soekarno Hatta No. 550|Kementerian Kesehatan RI - SIRS Online
38|3273558|RS Jantung dan Pembuluh Darah Paramarta|Khusus|Khusus - Jantung|C|-6.945615043727388|107.64051627597962|Jl. Soekarno Hatta No. 581|Kementerian Kesehatan RI - SIRS Online
39|3273559|RS Umum Mayapada Hospital Bandung|Umum|Rumah Sakit Umum|B|-6.9486101|107.6346276|Jl. Terusan Buah Batu No. 5|Kementerian Kesehatan RI - SIRS Online
40|3273560|RS Khusus Jantung dan Pembuluh Darah Melinda Cardio Vascular Center|Khusus|Khusus - Jantung|C|-6.905077093042333|107.60066318241729|Jl. Dr. Cipto No. 11 RT 04 RW 02|Kementerian Kesehatan RI - SIRS Online
41|3273561|RS Pasundan|Umum|Rumah Sakit Umum|C|-6.89815|107.61483|Jl. Haji Wasid No. 1|Kementerian Kesehatan RI - SIRS Online
42|3273562|RS Murni Teguh Naripan Bandung|Umum|Rumah Sakit Umum|C|-6.92076264381284|107.61631891473506|Jl. Naripan No. 89|Kementerian Kesehatan RI - SIRS Online
'@ | ConvertFrom-Csv -Delimiter '|'

if ($Rows.Count -ne 42 -or @($Rows | Where-Object category -eq 'Umum').Count -ne 27 -or @($Rows | Where-Object category -eq 'Khusus').Count -ne 15) {
  throw 'Daftar harus memiliki 42 rumah sakit: 27 umum dan 15 khusus.'
}

$Hospitals = @($Rows | ForEach-Object {
  [pscustomobject]@{
    id=[int]$_.id; name=$_.name; category=$_.category; type=$_.type; class=$_.class
    address=$_.address; lat=[double]::Parse($_.lat,[cultureinfo]::InvariantCulture)
    lng=[double]::Parse($_.lng,[cultureinfo]::InvariantCulture); sirsCode=$_.sirsCode
    sirsUrl="https://sirs.kemkes.go.id/fo/home/profile_rs/$($_.sirsCode)"
    coordinateSource=$_.coordinateSource
  }
})

ConvertTo-Json -InputObject @($Hospitals) -Depth 5 | Set-Content -LiteralPath (Join-Path $DataDir 'hospitals.json') -Encoding UTF8
"window.HOSPITALS = $(@($Hospitals) | ConvertTo-Json -Depth 5);" | Set-Content -LiteralPath (Join-Path $DataDir 'hospitals.js') -Encoding UTF8

$features = @($Hospitals | ForEach-Object {
  [pscustomobject]@{
    type='Feature'
    properties=[pscustomobject]@{
      id=$_.id; nama=$_.name; kategori=$_.category; jenis=$_.type; alamat=$_.address; kelas=$_.class
      kode_sirs=$_.sirsCode; sumber_koordinat=$_.coordinateSource; profil_sirs=$_.sirsUrl
    }
    geometry=[pscustomobject]@{ type='Point'; coordinates=@($_.lng,$_.lat) }
  }
})
[pscustomobject]@{
  type='FeatureCollection'; name='Rumah Sakit Kota Bandung'
  metadata=[pscustomobject]@{
    wilayah='Kota Bandung'; datum='WGS 84'; jumlah=42; rumah_sakit_umum=27; rumah_sakit_khusus=15
    daftar='Profil Kesehatan Kota Bandung 2025'; tanggal_kompilasi=$Compiled
    sumber_koordinat='SIRS Online Kementerian Kesehatan RI; koordinat RS Humana Prima dikoreksi menggunakan OpenStreetMap Photon'
  }
  features=$features
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $DataDir 'rumah_sakit_bandung.geojson') -Encoding UTF8

$CsvRows = $Hospitals | ForEach-Object {
  [pscustomobject]@{
    id=$_.id; name=$_.name; category=$_.category; type=$_.type; class=$_.class; address=$_.address
    lat=([double]$_.lat).ToString('R',[cultureinfo]::InvariantCulture)
    lng=([double]$_.lng).ToString('R',[cultureinfo]::InvariantCulture)
    sirsCode=$_.sirsCode; coordinateSource=$_.coordinateSource; sirsUrl=$_.sirsUrl
  }
}
$CsvRows | Export-Csv -LiteralPath (Join-Path $DataDir 'rumah_sakit_bandung.csv') -NoTypeInformation -Encoding UTF8
Write-Output "Dataset SIG siap: 42 lokasi (27 umum, 15 khusus), kompilasi $Compiled."
