# SIG Rumah Sakit Kota Bandung

Aplikasi Sistem Informasi Geografis berbasis web untuk menelusuri lokasi rumah sakit umum dan rumah sakit khusus di Kota Bandung. Aplikasi menampilkan direktori dan detail lokasi, lalu membuka lokasi terpilih pada peta Google Maps.

## Fitur

- Menampilkan 42 lokasi: 27 rumah sakit umum dan 15 rumah sakit khusus.
- Mencari fasilitas berdasarkan nama, alamat, atau kode SIRS.
- Menyaring daftar berdasarkan kategori rumah sakit.
- Menampilkan alamat, koordinat WGS 84, kelas rumah sakit, dan sumber koordinat.
- Membuka profil SIRS, lokasi pada Google Maps, atau petunjuk arah.
- Menyalin koordinat lokasi terpilih.

## Menjalankan aplikasi

Aplikasi tidak memerlukan instalasi paket atau server backend. Cara yang disarankan adalah menjalankan server web lokal dari folder aplikasi.

1. Unduh atau clone repositori, lalu buka folder root repositori, yaitu folder yang berisi `index.html`.
2. Jalankan perintah berikut di folder tersebut:

   ```powershell
   py -m http.server 8000
   ```

   Jika perintah `py` tidak tersedia, gunakan `python -m http.server 8000`.

3. Buka `http://localhost:8000` di peramban.

> Peta Google Maps dan tautan profil SIRS membutuhkan koneksi internet. Implementasi ini menggunakan URL Google Maps tanpa kunci API.

## Publikasi dengan GitHub Pages

Unggah **isi folder aplikasi ini** ke repositori GitHub, lalu buka **Settings → Pages**. Pilih **Deploy from a branch**, cabang `main`, dan folder `/ (root)`, kemudian simpan. Setelah GitHub Pages selesai menerbitkan situs, buka alamat yang ditampilkan di halaman Pages. Lihat [dokumentasi GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site) jika pilihan menu berubah.

Pastikan `index.html` dan folder `data/` berada di root repositori agar dataset dapat dimuat.

## Dataset dan sumber

Dataset yang disertakan merupakan snapshot per 25 Oktober 2026, bukan layanan data langsung. Snapshot aplikasi memuat 42 rumah sakit (27 umum dan 15 khusus). Nama dan jumlah daftar mengacu pada Profil Kesehatan Kota Bandung 2025; atribut alamat, kelas, dan koordinat mengacu pada SIRS Online Kementerian Kesehatan. Koordinat RS Umum Humana Prima dikoreksi menggunakan hasil OpenStreetMap Photon karena titik SIRS yang tersedia berada di luar Kota Bandung. Sumber koreksi juga dicatat pada data fasilitas.

Koordinat disimpan dalam datum WGS 84. Pada GeoJSON, urutan koordinat mengikuti standar GeoJSON yaitu `[longitude, latitude]`; pada CSV kolomnya bernama `lat` dan `lng`.

- Dinas Kesehatan Kota Bandung, [Profil Kesehatan Kota Bandung](https://dinkes.bandung.go.id/download-category/profil-kesehatan/).
- BPS Provinsi Jawa Barat, [Statistik rumah sakit menurut kabupaten/kota](https://jabar.bps.go.id/id/statistics-table/3/YmlzemNGUkNVblZLVVhOblREWnZXbkEzWld0eVVUMDkjMw%3D%3D/jumlah-rumah-sakit-umum--rumah-sakit-khusus--puskesmas--klinik-pratama--dan-posyandu-menurut-kabupaten-kota-di-provinsi-jawa-barat--2024.html) sebagai data pembanding.
- Kementerian Kesehatan RI, [SIRS Online](https://sirs.kemkes.go.id/fo/home/dashboard_rs?id=0).
- [OpenStreetMap Photon](https://photon.komoot.io/) untuk koreksi satu titik koordinat yang dijelaskan di atas.

## Struktur folder

```text
GIS ARDIYANTI/
├── index.html
├── README.md
├── .gitignore
├── data/
│   ├── hospitals.js                 # Dataset yang dibaca aplikasi
│   ├── hospitals.json              # Salinan dataset dalam JSON
│   ├── rumah_sakit_bandung.csv     # Salinan dataset dalam CSV
│   └── rumah_sakit_bandung.geojson # Salinan dataset dalam GeoJSON
└── tools/
    └── build_dataset.ps1           # Membuat ulang empat berkas dataset
```

## Memperbarui dataset

Data sumber yang digunakan untuk membangun berkas disimpan di `tools/build_dataset.ps1`. Setelah memeriksa data terbaru dari sumber resmi, perbarui daftar pada skrip tersebut. Dari PowerShell di folder aplikasi, jalankan:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\build_dataset.ps1
```

Skrip akan menghasilkan ulang `hospitals.js`, `hospitals.json`, `rumah_sakit_bandung.csv`, dan `rumah_sakit_bandung.geojson` di folder `data/`.

## Batasan penggunaan

Titik koordinat menunjukkan posisi representatif fasilitas berdasarkan sumber data, bukan hasil survei lapangan atau batas persil. Nama, alamat, kelas, koordinat, dan status operasional bisa berubah. Aplikasi ini untuk pembelajaran dan pencarian lokasi; hubungi rumah sakit untuk memastikan informasi layanan sebelum berkunjung.
